Collection of links to:

- formal methods tools [here](verification_synthesis.md).
- binary decision diagram (BDD) software libraries [here](bdd.md).
- packages for convex optimization in Python [here](optimization.md).

To the extent possible under law, the authors have waived all copyright and
related or neighboring rights to this text. For copying conditions, consult
COPYING.txt, which is [the CC0 Public Domain Dedication](http://creativecommons.org/publicdomain/zero/1.0/).
